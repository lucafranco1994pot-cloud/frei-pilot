ATLAS-FS-20261106-008 | Smallest SDK compatibility check | 2026-11-06

STATUS
  [CODE] sdk probe written; syntax validated locally.
  [CODE] GitHub Actions workflow parsed locally (YAML).
  [GETESTET] Pydantic-only prior probe repeated three times (not an SDK integration test).
  [OFFEN] SDK experiment not executed in this runtime because openai-agents is
          not installed, and DNS/network access for package downloads is disabled.
          No SDK outcomes are fabricated.

SOURCE PINS
  S0: openai/openai-agents-python
      cd26bbbc52847845fde73b9952b51e62e2bcbdc0
  S1: Lahari25/openai-agents-python
      a4d5954fe793390f3d15b7a241998f9d9fe231ff
  Python: 3.12 in Actions
  Pydantic: 2.12.3; pydantic-core: 2.41.4 (issue reporter's versions)

CONTENTS
  atlas_5448_sdk_probe.py       Public Runner.run + ScriptedModel.
  ATLAS_5448_SDK_REPAIR.yml     GitHub Actions workflow; read-only checkout and
                                artifact upload only. NOT run automatically.
  ATLAS_5448_local_preflight.json
                                Local Pydantic-only model/validator smoke test.
                                This is NOT evidence of SDK behavior.

RUN IN A REPO
  Copy atlas_5448_sdk_probe.py to repository root.
  Copy ATLAS_5448_SDK_REPAIR.yml to .github/workflows/ATLAS_5448_SDK_REPAIR.yml.
  Commit only if you expressly authorize that change in your repository.
  Use GitHub Actions > ATLAS FS008 - strict tool validation compatibility > Run workflow.
  Download both artifacts, atlas-5448-original_base and atlas-5448-contributor_patch.
  Compare their results.jsonl records by case and repetition.

INTERPRETATION
  - Function valid ticket: S0 should not call body, S1 should call body once.
    S1's nonmutating note validator may log [python, json].
  - Function invalid ticket: Tool must not execute. S1 might validate twice.
  - Function valid/invalid int: controls for strict JSON numeric handling.
  - Function compat values: path type and exact Decimal.as_tuple must remain.
  - Nested valid/invalid ticket: check child-model-call counts (not final output).
  - Timeout means test setup inadequate, not SDK defect.
  - Multiple validator calls alone mean an observable compatibility consideration,
    NOT a documented SDK contract breach or an exploit.

LIMITS
  The fix branch is the contributor's fork, not an integrated upstream release.
  Existing fork tests were checked and do not cover validator invocation counts.
  No mutations, no tool or runner mocking, no real model, no external side effects.
  The workflow must be committed to run; this bundle does not change your repository.

See upstream issue: https://github.com/openai/openai-agents-python/issues/5448
Contributor commit: https://github.com/Lahari25/openai-agents-python/commit/a4d5954fe793390f3d15b7a241998f9d9fe231ff

UPDATED: This bundle includes atlas_5448_verify.py and an evaluate job. The verifier
will return NOT_DECIDABLE (non-zero exit) if either matrix leg fails, data is missing,
source observations differ from frozen test expectations, or the tool/child execution
counts differ. Only after its positive result may the indicated observed behavior be
reported as an SDK test finding; it is still not a contract or security finding.
