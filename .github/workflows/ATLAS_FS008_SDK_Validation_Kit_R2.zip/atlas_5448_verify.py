#!/usr/bin/env python3
"""Classify paired ATLAS-FS-008 SDK evidence; missing/invalid data never count as PASS."""
import argparse, json, pathlib, sys

CASES = ['function_valid_ticket','function_invalid_ticket','function_valid_int',
         'function_invalid_int','function_compat_values','nested_valid_ticket','nested_invalid_ticket']

def load(path):
    rows={}; problems=[]
    for n,line in enumerate(pathlib.Path(path).read_text().splitlines(),1):
        try: v=json.loads(line)
        except Exception as e: problems.append(f'{path}:{n}: invalid JSON {e}');continue
        key=(v.get('case'),v.get('repetition'))
        if key in rows: problems.append(f'{path}:{n}: duplicate {key}')
        rows[key]=v
    for c in CASES:
        for rep in (1,2,3):
            if (c,rep) not in rows: problems.append(f'{path}: missing {(c,rep)}')
    return rows,problems

def mode_events(r):
    return [v.get('mode') for v in r.get('validation_events',[])]

def execute_count(r):
    if r['case'].startswith('nested_'): return r.get('child_model_calls')
    return r.get('tool_body_calls')

def check_pair(a,b):
    problems=[]; observations=[]
    for c in CASES:
      for rep in (1,2,3):
        x,y=a.get((c,rep)),b.get((c,rep))
        if x is None or y is None: continue
        for tag,r in [('S0',x),('S1',y)]:
          if r.get('harness_status')!='completed' or r.get('exit_code')!=0:
            problems.append(f'{c}/{rep} {tag}: harness not completed')
          if r.get('exception'):
            problems.append(f'{c}/{rep} {tag}: public exception {r["exception"]}')
          if r.get('outer_model_calls')!=2:
            problems.append(f'{c}/{rep} {tag}: expected 2 outer model calls')
          if r.get('outer_steps_left')!=0:
            problems.append(f'{c}/{rep} {tag}: model steps remain')
        count0,count1=execute_count(x),execute_count(y)
        expectation={
          'function_valid_ticket':(0,1), 'function_invalid_ticket':(0,0),
          'function_valid_int':(1,1), 'function_invalid_int':(0,0),
          'function_compat_values':(1,1), 'nested_valid_ticket':(0,1),
          'nested_invalid_ticket':(0,0)
        }[c]
        if (count0,count1)!=expectation:
          problems.append(f'{c}/{rep}: executions {(count0,count1)} != {expectation}')
        if c in ('function_valid_ticket','function_invalid_ticket','nested_valid_ticket','nested_invalid_ticket'):
          modes0,modes1=mode_events(x),mode_events(y)
          if modes0!=['python'] or modes1!=['python','json']:
            problems.append(f'{c}/{rep}: modes {modes0}/{modes1} != [python]/[python,json]')
        if c=='function_compat_values':
          if x.get('tool_arguments') != y.get('tool_arguments'):
            problems.append(f'{c}/{rep}: converted arguments changed')
          if not x.get('tool_arguments') or x['tool_arguments'][0].get('decimal_tuple') != {'sign':0,'digits':[5,0],'exponent':-1}:
            problems.append(f'{c}/{rep}: Decimal precision baseline not retained')
        observations.append({'case':c,'repetition':rep,'original_execution':count0,
                             'patch_execution':count1,'original_modes':mode_events(x),
                             'patch_modes':mode_events(y)})
    return problems,observations

def main():
    p=argparse.ArgumentParser();p.add_argument('original');p.add_argument('patch');p.add_argument('--output',default='atlas_5448_verdict.json'); args=p.parse_args()
    a,pa=load(args.original);b,pb=load(args.patch)
    errors,observations=check_pair(a,b)
    issues=pa+pb+errors
    verdict='NOT_DECIDABLE' if issues else 'B_PATCH_WITH_OBSERVED_VALIDATOR_DOUBLE_EXECUTION_NO_CONTRACT_BREACH_ESTABLISHED'
    out={'verdict':verdict,'validated_repetitions':len(observations),'issues':issues,'observations':observations,
         'limitations':['No security bypass demonstrated','Validator single execution not established as documented contract',
                        'Pydantic behavior and application effects must be interpreted separately']}
    pathlib.Path(args.output).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'verdict':verdict,'issues':issues,'validated_repetitions':len(observations)},ensure_ascii=False))
    return 0 if not issues else 1
if __name__=='__main__':sys.exit(main())
