#!/usr/bin/env python3
"""Verify frozen original runner, fixture, and pip version contract."""
from pathlib import Path
import hashlib
import sys
root = Path(__file__).resolve().parent
checks = []
for line in (root / 'INPUT_SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ', 1)
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    checks.append((name,actual == expected))
    print(('PASS' if actual == expected else 'FAIL') + ': '+name)
assert all(ok for _,ok in checks), 'Frozen input modified'
assert (root / 'ccxt_pilot_001/requirements.txt').read_text().strip() == 'ccxt==4.5.87'
print('FROZEN_INPUTS_OK')
