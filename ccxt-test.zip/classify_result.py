#!/usr/bin/env python3
"""Separate CI infrastructure from parser execution and observed output.

This is classification of the existing original_run.json; it is NOT a
new parser or a substitute for original package execution.
"""
import json
from pathlib import Path
from decimal import Decimal

root = Path(__file__).resolve().parent
pilot = root / 'ccxt_pilot_001'
result = pilot / 'original_run.json'
exitfile = pilot / 'original_exit_code.txt'
log = {
    'scope': 'CCXT-PILOT-001 unmodified parse_order; synthetic fixtures; no live exchange',
    'infrastructure': 'UNKNOWN',
    'original_method_executed': False,
    'finding': 'NOT_ESTABLISHED',
    'ci_runner_exit_code': None,
    'limits': ['fixture is reconstructed, not a captured live exchange response',
               'user_fills reference is synthetic',
               'offline market helper methods are replaced; parse_order itself is unmodified',
               'fetch_order is not tested'],
}
if exitfile.exists():
    try:
        log['ci_runner_exit_code'] = int(exitfile.read_text().strip())
    except (ValueError,OSError):
        pass
if not result.exists():
    log['infrastructure'] = 'INSTALLATION_FAILED_OR_NO_RESULT'
else:
    try:
        record = json.loads(result.read_text())
        log['raw_status'] = record.get('status')
        log['ccxt_version'] = record.get('installed_ccxt_version')
        log['ccxt_module_path'] = record.get('module_path')
        log['method_module_path'] = record.get('method_module_path')
        log['method_source_sha256'] = record.get('method_source_sha256')
        log['method_file_sha256'] = record.get('method_file_sha256')
        log['infrastructure'] = 'OK' if record.get('installed_ccxt_version')=='4.5.87' and record.get('metadata_ccxt_version')=='4.5.87' else 'VERSION_MISSING_OR_MISMATCH'
        cases = {c['case']: c for c in record.get('cases', [])}
        log['original_method_executed'] = bool(record.get('cases')) and record.get('method_under_test_patched') is False and record.get('method_matches_reported_branch') is True
        if log['infrastructure']=='OK' and log['original_method_executed'] and {'primary_terminal_filled','control_canceled_no_fill'}<=cases.keys():
            primary = cases['primary_terminal_filled']['parsed']
            control = cases['control_canceled_no_fill']['parsed']
            actual = Decimal(str(primary['filled']))
            ctrl = Decimal(str(control['filled']))
            log['primary_filled'] = str(actual)
            log['control_filled'] = str(ctrl)
            log['synthetic_fill_reference'] = '7.29'
            if actual == Decimal('8.33') and ctrl == 0:
                log['finding']='REPRODUCED_UNMODIFIED_PARSER_WITH_SYNTHETIC_FIXTURE'
            else:
                log['finding']='NOT_REPRODUCED'
        elif record.get('status') == 'NOT_REPRODUCED':
            log['finding']='NOT_REPRODUCED'
        else:
            log['finding']='BLOCKED_OR_UNRESOLVED'
    except Exception as e:
        log['infrastructure']='UNREADABLE_RESULT'
        log['error'] = f'{type(e).__name__}: {e}'
(root / 'ci_classification.json').write_text(json.dumps(log,sort_keys=True,indent=2)+'\n')
print(json.dumps(log,sort_keys=True,indent=2))
