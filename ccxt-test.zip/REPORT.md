# CCXT-PILOT-001 / CI-Übergabeprotokoll

## Ergebnis dieser Bearbeitung
- Das vorhandene Reproduktions-ZIP ist in `/mnt/data/CCXT_PILOT_001_ORIGINAL_RUN_GATE.zip` real vorhanden und wurde gelesen.
- `run_original.py`, `fixture.json` und `requirements.txt` sind byte-identisch in dieses Paket übernommen.
- GitHub-Actions-Workflow mit manueller Auslösung, minimalen Repo-Rechten, begrenzter Laufzeit und `always()`-Artefaktsicherung ist erstellt.
- Der statische Inputintegritätscheck wird lokal ausgeführt. Der CI-Ergebnisklassifizierer wird in kontrollierten Offline-Negativ-/Positivfixtures getestet.
- **Kein Repository ausgewählt, keine GitHub-Aktion ausgeführt, kein CCXT-Paketimport erfolgt.**

## Statusmatrix
| Aspekt | Status |
|---|---|
| Original-Runner übernommen | FERTIG |
| YAML-Paket und Ausführungspfad vorbereitet | FERTIG |
| Statische und synthetische CI-Selbsttests | SIEHE `VALIDATION.txt` |
| GitHub-Repository-Upload | NICHT DURCHGEFÜHRT |
| Originalpaket CCXT 4.5.87 tatsächlich ausgeführt | BLOCKIERT |
| Live-Hyperliquid-Orderstatus bestätigt | NICHT GETESTET |

## Herkunft
Der CI-Runner verwendet unverändert das Originaltest-Paket aus dieser Unterhaltung. Fixierter Anforderungspunkt ist `ccxt==4.5.87`. Der Tag `v4.5.87` wurde zuvor in der offiziellen CCXT-GitHub-Quelle überprüft. Der eigentliche CI-Originaltest bleibt ausstehend.
