# CCXT-PILOT-001: vorbereiteter GitHub-Actions-Lauf

**Status: WORKFLOW VORBEREITET, NICHT AUSGEFÜHRT.**

## Ziel
Einen echten Python-Paketlauf von `ccxt==4.5.87` mit dem **byte-identischen** vorhandenen `run_original.py` auf einem GitHub-hosted Runner durchführen. Ein Test wird **nicht** durch eine Parser-Kopie oder einen Mock ersetzt. Nur die Marktdaten-Hilfsfunktionen werden offline gestubbt, wie bereits im ursprünglichen Testtreiber definiert.

## Dateien
- `.github/workflows/ccxt-pilot-original.yml`: nur `workflow_dispatch`; nur `contents: read`; keine Börsenzugangsdaten, keine Trades, kein PR.
- `ccxt_pilot_001/run_original.py`: unverändert übernommen aus dem Paket `CCXT_PILOT_001_ORIGINAL_RUN_GATE.zip`.
- `ccxt_pilot_001/fixture.json`: Rekonstruktion aus Issue #30839, **keine Live-Börsenantwort**.
- `ccxt_pilot_001/requirements.txt`: exakt `ccxt==4.5.87`.
- `INPUT_SHA256SUMS` / `verify_inputs.py`: prüft unmodifizierte Eingabedateien vor der Installation.
- `classify_result.py`: prüft das Ergebnis des Originaltests nachträglich und trennt Infrastruktur, Ausführung und Befund. Er enthält **keine CCXT-Berechnungsfunktion**.

## Einmaliger manueller Start
1. Vertrautes **eigenes oder freigegebenes** GitHub-Repository wählen, in dem Actions erlaubt sind. Das ist **nicht** das Upstream-Repository `ccxt/ccxt`.
2. Die Ordnerstruktur aus diesem ZIP direkt ins Repository-Root übernehmen. Dateienpfade unverändert lassen. Einen eigenen Branch verwenden, falls sinnvoll; **nicht zu CCXT upstream pushen**.
3. Unter GitHub **Actions → CCXT Pilot 001 - original parser reproduction → Run workflow** den manuellen Run starten. Ggf. muss die Workflow-Datei zuerst auf dem Default Branch vorhanden sein, damit der Run-Button erscheint.
4. Den Artefakt-Download `ccxt-pilot-001-original-run-<run_id>` holen und anhand `ci_classification.json`, `original_run.json`, `installed_package.txt` und den Runner-Logs unabhängig bewerten.
5. `raw_status=ORIGINAL_PARSER_REPRODUCED` plus `finding=REPRODUCED_UNMODIFIED_PARSER_WITH_SYNTHETIC_FIXTURE` beweist den Originalparser-Befund unter **synthetischen Offline-Inputs**, nicht die Existenz einer heutigen Live-Börsenantwort. Ein roter Job bei `NOT_REPRODUCED` kann ein korrekter Untersuchungsausgang sein; `BLOCKED_*` ist Infrastruktur, nicht Fehlermeldung des CCXT-Parsers.

## Grenzen
- Dieser ZIP-Bestand ist **nicht** in ein GitHub-Repository übertragen worden.
- Ein echter CI-Lauf **wurde hier nicht gestartet**.
- `run_original.py` wurde im Paket unverändert kopiert; ob die Offline-Markt-Overrides mit der Distribution funktionieren, entscheidet erst der echte Lauf.
- GitHub Actions erfordert das passende Repository, Berechtigungen, verfügbare Actions-Kontingente und Zugriff auf PyPI. Keine Garantie vor Lauf.
- Die Main-Fixture ist anhand des Issues synthetisch rekonstruiert. `reduceOnlyCanceled` ist ein zusätzlicher synthetischer Grenzfall, keine bestätigte Börsenantwort.

## Beleg und Stoppregel
Ein Erfolg setzt voraus: `installed_ccxt_version=4.5.87`, korrekte Modulpfade und Fingerprints, originalen `parse_order` tatsächlich ausgeführt, Hauptfall `filled=8.33`, Kontrollfall `filled=0` und separate, ehrlich deklarierte synthetische Fill-Referenz `7.29`. Ohne echte CI-Protokolle bleibt Status **BLOCKIERT**.
