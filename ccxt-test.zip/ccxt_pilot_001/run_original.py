#!/usr/bin/env python3
"""Run the UNMODIFIED CCXT 4.5.87 hyperliquid.parse_order on offline fixtures.

Never uses exchange endpoints or private API credentials. Only auxiliary market
lookup methods are stubbed; the method under test is not patched or copied.

Exit 0: exact original package executed with observed expected issue behavior.
Exit 2: original method executed but outputs did not meet fixed expectations.
Exit 3: original package cannot be imported or has incorrect version.
Exit 4: other test harness/runtime failure (NOT a confirmed code regression).
"""
import hashlib
import importlib.metadata
import inspect
import json
import platform
import sys
import traceback
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED_VERSION = '4.5.87'
RESULT_FILE = ROOT / 'original_run.json'


def write_result(record, exit_code):
    record['exit_code'] = exit_code
    RESULT_FILE.write_text(json.dumps(record, indent=2, ensure_ascii=False, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(record, indent=2, ensure_ascii=False, sort_keys=True))
    return exit_code


def market_stub(_market_id, market=None, delimiter=None, market_type=None):
    """Provide offline symbol/precision metadata, not a trading account or order."""
    return {
        'id': 'AVAX', 'symbol': 'AVAX/USDC:USDC', 'base': 'AVAX',
        'quote': 'USDC', 'settle': 'USDC', 'type': 'swap',
        'spot': False, 'swap': True, 'future': False, 'option': False,
        'contract': True, 'linear': True, 'inverse': False,
        'contractSize': 1.0, 'precision': {'amount': 0.01, 'price': 0.01},
        'limits': {'amount': {'min': None, 'max': None},
                   'price': {'min': None, 'max': None}},
    }


def make_input(original_fixture, *, status, sz):
    """Reconstructed fixture; not an original captured exchange response."""
    copied = json.loads(json.dumps(original_fixture))
    copied['order']['sz'] = sz
    copied['status'] = status
    return copied


def execute():
    record = {
        'pilot': 'CCXT-PILOT-001',
        'scope': 'unmodified ccxt.hyperliquid.parse_order only; not fetch_order',
        'fixture_provenance': 'synthetic/reconstructed from public issue #30839',
        'reference_fill_provenance': 'synthetic user_fills based on public issue report',
        'fixture_live_capture': False,
        'ccxt_source_commit_for_prior_analysis': 'fb1bbcb9c69b1eecafc1688bbd2d78b2821c40db',
        'target_package_version': EXPECTED_VERSION,
        'python_version': platform.python_version(),
        'method_under_test_patched': False,
        'market_helper_overridden_for_offline_execution': True,
        'network_calls': False,
    }
    try:
        import ccxt
        from ccxt.base.precise import Precise
        record['installed_ccxt_version'] = str(ccxt.__version__)
        record['metadata_ccxt_version'] = importlib.metadata.version('ccxt')
        record['module_path'] = str(Path(ccxt.__file__).resolve())
        record['precise_import_path'] = str(Path(inspect.getfile(Precise)).resolve())
    except Exception as exc:
        record['status'] = 'BLOCKED_MISSING_OR_BROKEN_CCXT'
        record['error'] = f'{type(exc).__name__}: {exc}'
        return write_result(record, 3)

    if record['installed_ccxt_version'] != EXPECTED_VERSION or record['metadata_ccxt_version'] != EXPECTED_VERSION:
        record['status'] = 'BLOCKED_INCORRECT_CCXT_VERSION'
        return write_result(record, 3)

    try:
        exchange = ccxt.hyperliquid()
        method = type(exchange).parse_order
        method_source = inspect.getsource(method)
        record['method_module_path'] = str(Path(inspect.getfile(method)).resolve())
        record['method_source_sha256'] = hashlib.sha256(method_source.encode('utf-8')).hexdigest()
        record['method_file_sha256'] = hashlib.sha256(Path(inspect.getfile(method)).read_bytes()).hexdigest()
        record['method_matches_reported_branch'] = 'Precise.string_sub(totalAmount, remaining)' in method_source
        if not record['method_matches_reported_branch']:
            record['status'] = 'BLOCKED_DIFFERENT_METHOD_IMPLEMENTATION'
            return write_result(record, 3)

        # These two helpers only resolve a public market symbol offline.
        # Original class method remains byte-for-byte from installed package.
        exchange.coin_to_market_id = lambda coin: coin
        exchange.safe_market = market_stub
        if type(exchange).parse_order is not method:
            raise AssertionError('parse_order method changed')

        fixture = json.loads((ROOT / 'fixture.json').read_text(encoding='utf-8'))
        base = fixture['order_status']
        cases = (
            ('primary_terminal_filled', 'filled', '0.0', Decimal('8.33')),
            ('control_canceled_no_fill', 'canceled', '8.33', Decimal('0')),
            ('synthetic_reduce_only_canceled', 'reduceOnlyCanceled', '0.0', Decimal('8.33')),
        )
        results = []
        for case_name, status, size, expected in cases:
            item = make_input(base, status=status, sz=size)
            parsed = exchange.parse_order(item)  # Actual unchanged original package method
            out = {
                'case': case_name,
                'input_status': status,
                'input_origSz': item['order']['origSz'],
                'input_sz': size,
                'parsed': {
                    'id': parsed.get('id'), 'status': parsed.get('status'),
                    'amount': parsed.get('amount'), 'filled': parsed.get('filled'),
                    'remaining': parsed.get('remaining'),
                    'reduceOnly': parsed.get('reduceOnly'),
                },
                'expected_filled_for_reproduction': str(expected),
                'matches_expected': parsed.get('filled') is not None
                        and Decimal(str(parsed['filled'])) == expected,
                'input_is_live_exchange_capture': False,
            }
            results.append(out)

        record['cases'] = results
        record['independent_issue_fill_total'] = str(sum(
            (Decimal(str(x['sz'])) for x in fixture['user_fills']
             if str(x['oid']) == str(base['order']['oid'])), Decimal('0')))
        record['expected_gap'] = '1.04'
        record['actual_gap'] = str(Decimal(str(results[0]['parsed']['filled']))
                                   - Decimal(record['independent_issue_fill_total']))
        record['cases_passed'] = sum(item['matches_expected'] for item in results)
        record['cases_total'] = len(results)
        record['status'] = ('ORIGINAL_PARSER_REPRODUCED' if all(x['matches_expected'] for x in results)
                            and record['actual_gap'] == record['expected_gap']
                            else 'NOT_REPRODUCED')
        return write_result(record, 0 if record['status'] == 'ORIGINAL_PARSER_REPRODUCED' else 2)
    except Exception as exc:
        record['status'] = 'BLOCKED_RUNTIME_ERROR'
        record['error'] = f'{type(exc).__name__}: {exc}'
        record['traceback'] = traceback.format_exc()
        return write_result(record, 4)


if __name__ == '__main__':
    sys.exit(execute())
